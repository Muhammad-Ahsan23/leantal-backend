<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Jobs\AssignJobRequest;
use App\Http\Requests\Jobs\CreateJobRequest;
use App\Http\Requests\Jobs\UpdateJobRequest;
use App\Http\Requests\Jobs\UpdateJobStatusRequest;
use App\Models\Company;
use App\Models\Job;
use App\Models\User;
use App\Services\JobService;
use App\Services\SocialSharingService;
use App\Support\ActivityLogger;
use App\Support\CacheVersion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class JobController extends Controller
{
    public function __construct(
        protected JobService $jobs,
        protected SocialSharingService $socialSharing,
    ) {}

    /**
     * PRD Section 21 — list with search + filters. Uses
     * Job::scopeVisibleTo() for the RBAC-driven visibility rule
     * (Section 142: Recruiters see only their own assigned jobs).
     *
     * Cached per-user, per-filter-combination for 60s via Redis (tags
     * let JobService flush the whole company's cache on any mutation,
     * so this never serves stale data for longer than a write-to-read
     * race would already risk).
     */
    public function index(Request $request)
    {
        $user = $request->user();
        $connection = $user->getConnectionName();

        $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $filters = $request->only(['status', 'department', 'search', 'assigned_user_id']);

        // Pagination is opt-in: the Jobs page sends ?page=, while pickers/dashboard (which need every job)
        // keep calling without it and get the full list exactly as before.
        $paginate = $request->has('page') || $request->has('per_page');
        $page = max(1, (int) $request->query('page', 1));
        $perPage = min(100, max(1, (int) $request->query('per_page', 20)));

        $version = CacheVersion::get("company:{$user->company_id}:jobs");
        $cacheKey = "jobs:v{$version}:".$user->id.':'.md5(json_encode([$filters, $paginate ? [$page, $perPage] : null]));

        $result = Cache::remember($cacheKey, 60, function () use ($user, $connection, $filters, $paginate, $page, $perPage) {
            $query = Job::on($connection)->visibleTo($user)->with('assignedUser:id,name');

            if (!empty($filters['status'])) {
                $query->where('status', $filters['status']);
            }
            if (!empty($filters['department'])) {
                $query->where('department', $filters['department']);
            }
            if (!empty($filters['assigned_user_id'])) {
                $query->where('assigned_user_id', $filters['assigned_user_id']);
            }
            if (!empty($filters['search'])) {
                $query->where('title', 'ilike', '%'.$filters['search'].'%');
            }

            // id as a tie-breaker so two jobs created in the same instant never swap pages.
            $query->orderByDesc('created_at')->orderBy('id');

            $meta = null;
            if ($paginate) {
                $paginator = $query->paginate($perPage, ['*'], 'page', $page);
                $jobs = $paginator->getCollection();
                $meta = [
                    'current_page' => $paginator->currentPage(),
                    'last_page' => $paginator->lastPage(),
                    'per_page' => $paginator->perPage(),
                    'total' => $paginator->total(),
                ];
            } else {
                $jobs = $query->limit(500)->get(); // safety net: an unpaged call never pulls a whole table
            }

            // PRD Section 21 — "Applicant count" column. Single grouped
            // query (not one-per-job) to avoid N+1 as the jobs list grows.
            $counts = DB::connection($connection)->table('applications')
                ->select('job_id', DB::raw('count(*) as cnt'))
                ->whereIn('job_id', $jobs->pluck('id'))
                ->groupBy('job_id')
                ->pluck('cnt', 'job_id');

            $jobs->each(fn ($job) => $job->applicants_count = $counts[$job->id] ?? 0);

            return ['jobs' => $jobs, 'meta' => $meta];
        });

        return response()->json($result['meta'] === null
            ? ['jobs' => $result['jobs']]
            : ['jobs' => $result['jobs'], 'meta' => $result['meta']]);
    }

    public function store(CreateJobRequest $request)
    {
        $user = $request->user();

        if (!$user->can('create', Job::class)) {
            return response()->json(['message' => 'You do not have permission to create jobs.'], 403);
        }

        $connection = $user->getConnectionName();

        try {
            $job = $this->jobs->create($request->validated(), $user, $connection);
        } catch (\RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        // PRD Section 65 — "Sarah Johnson published Backend Engineer"
        ActivityLogger::log($connection, $user->company_id, $user->id, $job->status === 'published' ? 'job.published' : 'job.created', 'job', $job->id, [
            'job_title' => $job->title,
        ]);

        return response()->json(['job' => $job->load('pipelineStages')], 201);
    }

    public function show(Request $request, string $id)
    {
        $user = $request->user();
        $connection = $user->getConnectionName();
        $job = Job::on($connection)->with(['pipelineStages', 'assignedUser:id,name', 'creator:id,name'])->find($id);

        if (!$job) {
            return response()->json(['message' => 'Job not found.'], 404);
        }

        if (!$user->can('view', $job)) {
            return response()->json(['message' => 'You do not have permission to view this job.'], 403);
        }

        $job->applicants_count = DB::connection($connection)->table('applications')->where('job_id', $job->id)->count();

        return response()->json(['job' => $job]);
    }

    public function update(UpdateJobRequest $request, string $id)
    {
        $user = $request->user();
        $connection = $user->getConnectionName();
        $job = Job::on($connection)->find($id);

        if (!$job) {
            return response()->json(['message' => 'Job not found.'], 404);
        }

        if (!$user->can('update', $job)) {
            return response()->json(['message' => 'You do not have permission to edit this job.'], 403);
        }

        $job = $this->jobs->update($job, $request->validated(), $connection);

        ActivityLogger::log($connection, $user->company_id, $user->id, 'job.updated', 'job', $job->id, ['job_title' => $job->title]);

        return response()->json(['job' => $job]);
    }

    /**
     * PRD Section 22/92 — status lifecycle (Draft/Published/Paused/
     * Closed/Archived), enforced via JobService::TRANSITIONS so an
     * invalid jump (e.g. Draft -> Closed) is rejected with a clear error.
     */
    public function updateStatus(UpdateJobStatusRequest $request, string $id)
    {
        $user = $request->user();
        $connection = $user->getConnectionName();
        $job = Job::on($connection)->find($id);

        if (!$job) {
            return response()->json(['message' => 'Job not found.'], 404);
        }

        if (!$user->can('update', $job)) {
            return response()->json(['message' => 'You do not have permission to change this job\'s status.'], 403);
        }

        try {
            $previousStatus = $job->status;
            $job = $this->jobs->transitionStatus($job, $request->validated()['status'], $connection);
        } catch (\InvalidArgumentException|\RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        // PRD Section 65 — job.published / job.paused / job.closed / job.archived
        ActivityLogger::log($connection, $user->company_id, $user->id, 'job.'.$job->status, 'job', $job->id, [
            'job_title' => $job->title,
            'from_status' => $previousStatus,
        ]);

        return response()->json(['job' => $job]);
    }

    public function assign(AssignJobRequest $request, string $id)
    {
        $user = $request->user();
        $connection = $user->getConnectionName();
        $job = Job::on($connection)->find($id);

        if (!$job) {
            return response()->json(['message' => 'Job not found.'], 404);
        }

        if (!$user->can('assign', $job)) {
            return response()->json(['message' => 'You do not have permission to assign this job.'], 403);
        }

        $targetUserId = $request->validated()['assigned_user_id'];
        $targetUser = User::on($connection)->where('company_id', $user->company_id)->find($targetUserId);

        if (!$targetUser) {
            return response()->json(['message' => 'That user was not found in your company.'], 422);
        }

        $job = $this->jobs->assign($job, $targetUserId, $connection);

        // PRD Section 65 — "Sarah Johnson assigned Backend Engineer to Rahul"
        ActivityLogger::log($connection, $user->company_id, $user->id, 'job.assigned', 'job', $job->id, [
            'job_title' => $job->title,
            'assigned_user_id' => $targetUserId,
            'assigned_user_name' => User::on($connection)->where('id', $targetUserId)->value('name'),
        ]);

        return response()->json(['job' => $job]);
    }

    /**
     * PRD Section 52 — "After publishing a job, provide Share Job
     * buttons: LinkedIn, X, Threads." Restricted to published jobs
     * only — sharing a draft/unpublished job would link to a page
     * candidates can't actually apply from.
     */
    public function shareLinks(Request $request, string $id)
    {
        $user = $request->user();
        $connection = $user->getConnectionName();
        $job = Job::on($connection)->find($id);

        if (!$job) {
            return response()->json(['message' => 'Job not found.'], 404);
        }

        if (!$user->can('view', $job)) {
            return response()->json(['message' => 'You do not have permission to view this job.'], 403);
        }

        if ($job->status !== 'published') {
            return response()->json(['message' => 'Share links are only available for published jobs.'], 422);
        }

        $company = Company::on($connection)->find($job->company_id);

        return response()->json($this->socialSharing->buildShareLinks($job, $company));
    }
}
