<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory, HasUuids;

    protected $fillable = [
        'name',
        'website',
        'location',
        'country_code',
        'region',
        'slug',
        'careers_description',
        'plan',
        'subscription_status',
        'trial_start',
        'trial_end',
        'past_due_since',
        // BUG FIX: these were missing, so Eloquent's mass-assignment
        // protection silently DROPPED them on every ->update([...]):
        //  - deletion trio: CompanyController::delete() never persisted anything
        //  - Creem ids: CreemWebhookController saved plan/status but never the
        //    customer/subscription ids (portal + plan-change need them)
        // All callers pass controlled/validated arrays, never raw request input.
        'deletion_requested_at',
        'data_retention_choice',
        'deleted_at',
        'creem_customer_id',
        'creem_subscription_id',
    ];

    protected $casts = [
        'trial_start' => 'datetime',
        'trial_end' => 'datetime',
        'past_due_since' => 'datetime',
        'deletion_requested_at' => 'datetime',
        'deleted_at' => 'datetime',
        'suspended_at' => 'datetime',
    ];

    // Never expose internal billing/deletion fields in API responses by default
    protected $hidden = [
        'creem_customer_id',
        'creem_subscription_id',
        'deletion_requested_at',
        'data_retention_choice',
        'suspended_reason',
    ];

    public function users()
    {
        return $this->hasMany(User::class);
    }

    /**
     * PRD Section 90 — Plan Seat Enforcement.
     * Returns null for unlimited (Scale plan).
     */
    public function seatLimit(): ?int
    {
        return match ($this->plan) {
            'free' => 1,
            'starter' => 3,
            'team' => 15,
            'scale' => null,
            default => 1,
        };
    }

    /**
     * PRD Section 91 — Job Limits. "Archived and closed jobs do not count
     * against active limits" — implies draft/published/paused DO count,
     * which is what JobService checks against this.
     */
    public function jobLimit(): ?int
    {
        return $this->plan === 'free' ? 1 : null;
    }
}
