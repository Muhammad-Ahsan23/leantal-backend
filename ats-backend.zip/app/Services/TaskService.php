<?php

namespace App\Services;

use App\Models\Task;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TaskService
{
    public function __construct(protected NotificationService $notifications) {}

    /**
     * PRD Section 62-63 — Owner/HM create tasks (enforced via
     * TaskPolicy::create() in the controller before this runs).
     * PRD Section 20 — "Task assigned to you" notification trigger.
     */
    public function create(array $data, User $creator, string $companyId, string $connection): Task
    {
        $task = Task::on($connection)->create([
            ...$data,
            'company_id' => $companyId,
            'created_by' => $creator->id,
            'status' => 'to_do',
            'auto_generated' => false,
        ]);

        $this->logActivity($connection, $companyId, $creator->id, 'task.created', $task->id, [
            'title' => $task->title,
            'assigned_to' => $task->assigned_user_id,
        ]);

        $assignedUser = User::on($connection)->find($task->assigned_user_id);
        if ($assignedUser) {
            $this->notifications->notify($assignedUser, 'task_assigned', "You were assigned a task: {$task->title}", $connection, "/tasks/{$task->id}");
        }

        return $task;
    }

    /** Edit details. Notifies the new assignee when the task is reassigned. */
    public function update(Task $task, array $data, User $actor, string $connection): Task
    {
        $oldAssignee = $task->assigned_user_id;
        $task->update($data);

        $this->logActivity($connection, $task->company_id, $actor->id, 'task.updated', $task->id, [
            'title' => $task->title,
            'fields' => array_keys($data),
        ]);

        if ($task->assigned_user_id !== $oldAssignee) {
            $assignee = User::on($connection)->find($task->assigned_user_id);
            if ($assignee) {
                $this->notifications->notify($assignee, 'task_assigned', "You were assigned a task: {$task->title}", $connection, "/tasks/{$task->id}");
            }
        }

        return $task->fresh();
    }

    /**
     * PRD Section 64 — Kanban-style status tracking. No transition
     * restrictions (like Candidate stages, unlike Job status) — any
     * column to any column, since the PRD doesn't define a required order
     * for To Do / In Progress / Done / Cancelled.
     */
    public function updateStatus(Task $task, string $newStatus, User $actor, string $connection): Task
    {
        $task->update(['status' => $newStatus]);

        $this->logActivity($connection, $task->company_id, $actor->id, 'task.status_changed', $task->id, [
            'title' => $task->title,
            'new_status' => $newStatus,
        ]);

        return $task->fresh();
    }

    protected function logActivity(string $connection, string $companyId, string $actorId, string $action, string $taskId, array $metadata = []): void
    {
        DB::connection($connection)->table('activity')->insert([
            'id' => (string) Str::uuid(),
            'company_id' => $companyId,
            'actor_id' => $actorId,
            'action' => $action,
            'object_type' => 'task',
            'object_id' => $taskId,
            'metadata' => json_encode($metadata),
            'created_at' => now(),
        ]);
    }
}
