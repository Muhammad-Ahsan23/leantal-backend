<?php

namespace App\Jobs;

use App\Models\Application;
use App\Models\Company;
use App\Models\Job;
use App\Models\User;
use App\Services\EmailService;
use App\Services\SystemEventLogger;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

/**
 * ONE email of a bulk send. The controller queues one of these per candidate, spaced out in time, so a 100-candidate send
 * never holds a web request open and never hits Gmail / Outlook / SMTP in one burst. Only ids are stored in the queue
 * (never models, never the Gmail token); everything is re-read when the job runs, so a candidate who was archived or
 * re-assigned in the meantime is checked again.
 *
 * Retries: a mail-transport / provider hiccup is retried (3 tries, 1 min then 5 min apart). A message problem (a template
 * variable with no value) cannot be fixed by trying again, so it is logged to the Debugging view and dropped. A cache key
 * makes a retry after a half-finished send (mail went out, bookkeeping failed) skip the candidate instead of mailing twice.
 */
class SendBulkEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable;

    public int $tries = 3;
    public int $timeout = 60;

    public function __construct(
        public string $dbConnection,
        public string $batchId,
        public string $applicationId,
        public string $actorId,
        public string $mode,
        public ?string $templateId,
        public ?string $subject,
        public ?string $body,
    ) {}

    public function backoff(): array
    {
        return [60, 300];
    }

    public function handle(EmailService $emails): void
    {
        $doneKey = "bulk-email:{$this->batchId}:{$this->applicationId}";
        if (Cache::has($doneKey)) {
            return;
        }

        $application = Application::on($this->dbConnection)->with('candidate')->find($this->applicationId);
        $actor = User::on($this->dbConnection)->find($this->actorId);
        $candidate = $application?->candidate;

        if (!$application || !$actor || !$candidate || !$candidate->email || !$actor->can('update', $candidate)) {
            return; // gone, or no longer allowed: nothing to send
        }

        $company = Company::on($this->dbConnection)->find($actor->company_id);
        $job = Job::on($this->dbConnection)->find($application->job_id);

        try {
            if ($this->mode === 'send_personal') {
                $emails->sendPersonalEmail($candidate, $actor, $this->templateId, $this->subject, $this->body, $job, null, $company->name ?? '', $this->dbConnection);
            } else {
                $emails->sendSystemEmail($candidate, $this->templateId, $this->subject, $this->body, $job, $actor, null, $company->name ?? '', $actor, $this->dbConnection);
            }
        } catch (TransportExceptionInterface $e) {
            throw $e; // SMTP down: try again later
        } catch (\RuntimeException $e) {
            // A template problem will not fix itself: record it and stop. Anything else (a Gmail / Outlook API error) is retried.
            if (preg_match('/unfilled variables|template not found|required/i', $e->getMessage())) {
                $this->record($e->getMessage());
                return;
            }
            throw $e;
        }

        Cache::put($doneKey, 1, now()->addDay());
    }

    // Called once every try has failed.
    public function failed(\Throwable $e): void
    {
        $this->record($e instanceof TransportExceptionInterface ? 'Mail transport failed after 3 tries.' : $e->getMessage());
    }

    protected function record(string $message): void
    {
        try {
            $actor = User::on($this->dbConnection)->find($this->actorId);
            app(SystemEventLogger::class)->log('email', 'Bulk email: '.$message, $actor?->company_id, str_replace('pgsql_', '', $this->dbConnection), [
                'batch_id' => $this->batchId,
                'application_id' => $this->applicationId,
                'mode' => $this->mode,
                'template_id' => $this->templateId,
                'user_id' => $this->actorId,
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    }
}
