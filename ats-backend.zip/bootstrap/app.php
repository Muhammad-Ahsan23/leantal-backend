<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )

    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->api(prepend: [
            \App\Http\Middleware\EnforceMaintenanceMode::class,
        ]);
        $middleware->api(append: [
            \App\Http\Middleware\EnsureCompanyIsNotSuspended::class,
            \App\Http\Middleware\EnsureCompanyIsNotReadOnly::class,
            \App\Http\Middleware\RestrictImpersonation::class,
        ]);

        // 'super-admin' — PRD Section 145, used on the Super Admin
        // route group (routes/api.php) via ->middleware('super-admin').
        // Deliberately a NAMED alias (applied selectively to specific
        // routes), not appended globally like EnsureCompanyIsNotReadOnly
        // above — it must NEVER run on customer-facing routes.
        $middleware->alias([
            'super-admin' => \App\Http\Middleware\EnsureSuperAdmin::class,
            'admin.can' => \App\Http\Middleware\EnsureAdminCan::class,
            'admin.owner' => \App\Http\Middleware\EnsureAdminIsOwner::class,
            'admin.fresh' => \App\Http\Middleware\EnsureRecentMfa::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn(Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
